public interface Hashable<T>{
  public int getKey();
}
