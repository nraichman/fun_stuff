public interface Hashable<K extends Comparable> extends Comparable{
  public K getKey();
}
